package androidappdevworkshop.example.com.adilla.macaddressserver.Object;

/**
 * Created by Adilla on 20/5/2016.
 */
public class Subject {

    private String code;
    private String name;

    public Subject(){

    }

    public void setCode(String code){
        this.code = code;
    }

    public String getCode(){
        return code;
    }

    public void setName(String name){
        this.name = name;
    }

    public String getName(){
        return name;
    }

    /*public boolean verifyStudentRes(){

    }*/
}
