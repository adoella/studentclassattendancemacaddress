package androidappdevworkshop.example.com.adilla.macaddressserver.Object;

/**
 * Created by Adilla on 22/5/2016.
 */
public class Lecturer {

    private String userId;
    private String name;

    public Lecturer(){

    }

    public void setUserId(String userId){
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
